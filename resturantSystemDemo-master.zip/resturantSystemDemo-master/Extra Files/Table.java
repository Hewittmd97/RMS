public class Table {
	private String status;
	private int X_coordinate;
	private int Y_coordinate;
	private int tableID;
	/*
		tableID values:
		"occupied" - The table has customers sitting at it
		"dirty" - The customers have left but the table has not been cleaned yet
		"clean" - The table has been cleaned and it's ready to sit more customers
	*/


	public Table(int _X_coordinate, int _Y_coordinate, int _tableID) {
		X_coordinate = _X_coordinate;
		Y_coordinate = _Y_coordinate;
		tableID = _tableID;
		status = "clean";
	}

	public int getTableID() {
		return tableID;
	}
	public void setTableID(int _tableID) {
		this.tableID = _tableID;
	}

	public int getXCoordinate() {
		return X_coordinate;
	}
	public int getYCoordinate() {
		return Y_coordinate;
	}
	public void setCoordinates(int x, int y) {
		X_coordinate = x;
		Y_coordinate = y;
	}

	public String getStatus() {
		return status;
	}
	public void setStatus(String _Status) {
		if(_Status == "occupied" || _Status == "dirty" || _Status == "clean") {
			status = _Status;
		}
	}
}
