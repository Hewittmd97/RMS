import java.util.ArrayList;

public class Order 
{
    private String status;
    private ArrayList<FoodItem> orderItems;
    
    public Order()
    {
        
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public ArrayList<FoodItem> getOrderItems() {
        return orderItems;
    }

    public void setOrderItems(ArrayList<FoodItem> orderItems) {
        this.orderItems = orderItems;
    }
    
    public void addItem(FoodItem fi)
    {
        orderItems.add(fi);
    }
    
    public String createSale()
    {
        String temp = "";
        for(int i = 0; i < orderItems.size(); i++)
        {
            temp += orderItems.get(i).toString();
        }
        return temp;
    }
    
}
