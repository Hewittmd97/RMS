import java.util.ArrayList;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class HandHeldDevice extends Application {
    
        public static void main(String args[]){
            //Java FX 
            launch(args);
        }
    
        @Override
        public void start(Stage primaryStage) {
            
            //Create instance of device
            HandHeldDevice device = new HandHeldDevice();
            device.demo(); // instantiates tables and food items
            primaryStage.setTitle("Resturant Management System");
           
            //Available Tables
            Pane root = new Pane();
            
            for(int i = 0; i < device.tables.size(); i++){
                
                Button btn = new Button();
                
                Table table = device.tables.get(i);
                String status = table.getStatus();
                
                String tableLabel = "Table #" + table.getTableID();

                btn.setText(tableLabel);
                
                int x = device.tables.get(i).getXCoordinate();
                int y = device.tables.get(i).getYCoordinate();
                
                
                btn.setLayoutX(x);
                btn.setLayoutY(y);
                
                btn.setOnAction(new EventHandler<ActionEvent>() {

                    @Override
                    public void handle(ActionEvent event) {
                        BorderPane border = new BorderPane();
                        VBox vbox = new VBox();
                        //Fill vbox
                        //set top to label
                        Label b = new Label(tableLabel);
                        border.setTop(b);
                        
                        
                        // add Dirty button if the table was occupied.
                        if(status.equals("occupied")){ 
                            //Dirty Button
                             Button dirtyButton = new Button();
                             dirtyButton.setText("Mark Dirty");
                             dirtyButton.setOnAction(new EventHandler<ActionEvent>() {
                                 @Override
                                 public void handle(ActionEvent event) {
                                     //To do, write code that marks this table as dirty

                                 }
                                 });

                             vbox.getChildren().add(dirtyButton);
                        }
                        //Open Order button
                        Button orderButton = new Button();
                        orderButton.setText("Open Order");
                        orderButton.setOnAction(new EventHandler<ActionEvent>() {
                            @Override
                            public void handle(ActionEvent event) {
                                //To do, write code that opens order if it exists
                                
                            }
                            });
                        
                        vbox.getChildren().add(orderButton);
                        
                        // add vbox to border pane
                        border.setCenter(vbox);
                        Button back = new Button();
                        back.setText("Back");
                        back.setOnAction(new EventHandler<ActionEvent>() {
                            @Override
                            public void handle(ActionEvent event) {
                                //Go back to start
                                start(primaryStage);
                            }
                            });
                        border.setBottom(back);
                        Scene scene = new Scene(border, 500, 500);
                        primaryStage.setScene(scene);
                        primaryStage.show();
                    }
                });
                
                root.getChildren().add(btn);
         
            }
            Scene scene = new Scene(root, 500, 300);
            scene.setFill(Color.LIGHTGRAY);
            primaryStage.setScene(scene);
            primaryStage.show();
        }
        
        
	// Object Code
        private ArrayList<Order> ord;
	private ArrayList<Table> tables;
	private ArrayList<FoodItem> menu;

	public HandHeldDevice() {
		ord = new ArrayList<Order>();
		tables = new ArrayList<Table>();
		menu = new ArrayList<FoodItem>();
                
	}
        private void demo(){
            int[] x = {120, 220, 200, 320, 300};

            int[] y = {100, 100, 200, 100, 200};
            
            for( int i = 0; i < 5; i++){
                Table table = new Table(x[i], y[i], i);
                tables.add(table);
            }
        }
}
