import java.util.ArrayList;

public class Order 
{
    private String status;
    private ArrayList<FoodItem> orderItems;
    private Table myTable;
    
    
    public Order(Table newTable) {
        this.status = "in progress";
        this.orderItems = new ArrayList<>();
        this.myTable = newTable;
    }

    public Table getTable() {
        return myTable;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        if(status == "complete" || status == "in progress")
            this.status = status;
    }

    public ArrayList<FoodItem> getOrderItems() {
        return orderItems;
    }

    public void setOrderItems(ArrayList<FoodItem> orderItems) {
        this.orderItems = orderItems;
    }
    public void addItem(FoodItem fi){
        this.orderItems.add(fi);
    }
    
}
