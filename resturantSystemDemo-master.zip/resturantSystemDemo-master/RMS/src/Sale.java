import java.util.ArrayList;

public class Sale {
  private double total;
  private ArrayList<FoodItem> orderItems;

  public Sale(Order order) {
    orderItems = order.getOrderItems();

    total = 0;
    for (FoodItem i : orderItems) {
      total += i.getPrice();
    }

    total *= 1.0825;
  }

  public String printCheck() {
     
    String s = "";
      
    for (FoodItem item : orderItems) {
      s += String.format("%-16s%.2f\n",item.getName(),item.getPrice());
    }

    s += String.format("%-16s%.2f","TOTAL:",total);
    
    return s;
  }
}
