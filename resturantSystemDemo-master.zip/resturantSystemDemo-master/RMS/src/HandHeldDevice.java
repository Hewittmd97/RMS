import java.util.ArrayList;
import java.util.Iterator;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class HandHeldDevice extends Application {
    private static final String OCCUPIED = "occupied";
    private static final String COMPLETE = "complete";
    private static final String INPROGRESS = "in progress";
    private static final String DIRTY = "dirty";
    private static final String CLEAN = "clean";


    /* Main Code, and JavaFX code */
    public static void main(String args[]){
        //Java FX
        launch(args);
    }

    public void makeOrderInterface(Stage primaryStage, HandHeldDevice device, int thisTablesOrderIndex, Order thisTablesOrder) {
        final HandHeldDevice deviceF = device;
        // ORDER INTERFACE
        Button[] menu = new Button[deviceF.menu.size()];
        for(int f = 0; f < deviceF.menu.size(); f++)
        {
            Button foodItem =  new Button();

            FoodItem itemInstance = deviceF.menu.get(f);

            foodItem.setText(itemInstance.getName() + "\n$" + itemInstance.getPrice() + "\n" + itemInstance.getDesc());
            foodItem.setOnAction((ActionEvent onFoodButtonClick) ->
            {
                Order r = deviceF.ord.get(thisTablesOrderIndex);
                r.addItem(itemInstance);
                makeOrderInterface(primaryStage, deviceF, thisTablesOrderIndex, thisTablesOrder);
            });
            menu[f] = foodItem;
        }
        Label currentOrder = new Label();
        Order r = deviceF.ord.get(thisTablesOrderIndex);
        String s = new Sale(r).printCheck();
        currentOrder.setText(s);
        // Complete order and create bill button
        Button createSale = new Button();
        createSale.setText("Close Order");
        createSale.setOnAction((ActionEvent event3) ->
        {
            deviceF.ord.get(thisTablesOrderIndex).setStatus(COMPLETE);
            Sale thisSale = new Sale(thisTablesOrder);
            String bill = thisSale.printCheck();
            Label billLabel = new Label(bill);

            Button back = new Button();
            back.setText("Back");
             back.setOnAction((ActionEvent event5) -> {
              //Go back to start
              start(primaryStage, deviceF);
            });
            HBox billBox = new HBox();
            billBox.getChildren().add(billLabel);
            billBox.getChildren().add(back);
            Scene scene = new Scene(billBox, 500, 500);
            primaryStage.setScene(scene);
            primaryStage.show();

        });

        //back button
        Button back = new Button();
        back.setText("Back");
        back.setOnAction((ActionEvent event5) -> {
            //Go back to start
            start(primaryStage, deviceF);
        });
        HBox hbox = new HBox();
        for(int f = 0; f < menu.length; f++)
        {
            hbox.getChildren().add(menu[f]);
        }
        VBox orderMenu = new VBox();
        orderMenu.getChildren().add(hbox);
        orderMenu.getChildren().add(currentOrder);
        orderMenu.getChildren().add(createSale);
        orderMenu.getChildren().add(back);
        Scene scene = new Scene(orderMenu, 500, 500);
        primaryStage.setScene(scene);
        primaryStage.show();

    }
    
    @Override
    public void start(Stage primaryStage) {
        start(primaryStage,  null);
    }
    public void start(Stage primaryStage, HandHeldDevice device) {
        //Create instance of device
        if(device == null){
            device = new HandHeldDevice();
            device.demo(); // instantiates tables and food items
        }
        primaryStage.setTitle("Resturant Management System");

        final HandHeldDevice deviceF = device;
        Pane root = new Pane();
        //For every table create a button Available Tables
        for(int i = 0; i < deviceF.tables.size(); i++){

            Button btn = new Button();

            Table table = device.tables.get(i);
            String status = table.getStatus();

            String tableLabel = "Table #" + table.getTableID() + "\n" + table.getStatus();

            btn.setText(tableLabel);

            int x = device.tables.get(i).getXCoordinate();
            int y = device.tables.get(i).getYCoordinate();

            btn.setLayoutX(x);
            btn.setLayoutY(y);
            if(table.getStatus() == OCCUPIED)
                btn.setOnAction((ActionEvent event) -> {
                    BorderPane border = new BorderPane();
                    VBox vbox = new VBox();
                    //Fill vbox
                    //set top to label
                    Label b = new Label(tableLabel);
                    border.setTop(b);
                    Order thisOrd  = null;
                    int idx = -1;
                    String orderStatus = "";

                    for (int j = 0; j < deviceF.ord.size(); j++) {
                        if (deviceF.ord.get(j).getTable().getTableID() == table.getTableID()) {
                            thisOrd = deviceF.ord.get(j);
                            idx = j;
                            orderStatus = deviceF.ord.get(j).getStatus();
                        }
                    }
                    final int thisTablesOrderIndex = idx;
                    final Order thisTablesOrder = thisOrd;
                    // add Dirty button if the table was occupied, has an order that is complete
                    if(status.equals(OCCUPIED)&& orderStatus.equals(COMPLETE)){
                        //Dirty Button
                        Button dirtyButton = new Button();
                        dirtyButton.setText("Mark Dirty");
                        dirtyButton.setOnAction((ActionEvent event1) -> {
                            // mark this table as dirty and go back to table interface
                            deviceF.ord.remove(thisTablesOrderIndex);
                            deviceF.markTableAsDirty(table.getTableID());
                            start(primaryStage, deviceF);
                        });

                        vbox.getChildren().add(dirtyButton);
                    }
                    //Open Order button
                    if(orderStatus == INPROGRESS){
                        Button orderButton = new Button();
                        orderButton.setText("Open Order");
                        orderButton.setOnAction((ActionEvent event1) -> {
                            makeOrderInterface(primaryStage, deviceF, thisTablesOrderIndex, thisTablesOrder);
                        });
                        vbox.getChildren().add(orderButton);
                    }
                    // add vbox with buttons added above to border pane
                    border.setCenter(vbox);
                    Button back = new Button();
                    back.setText("Back");
                    back.setOnAction((ActionEvent event1) -> {
                        //Go back to start
                        start(primaryStage, deviceF);
                    });
                    border.setBottom(back);
                    Scene scene = new Scene(border, 500, 500);
                    primaryStage.setScene(scene);
                    primaryStage.show();
                });

            root.getChildren().add(btn);

        }
        Scene scene = new Scene(root, 1100, 500);
        scene.setFill(Color.LIGHTGRAY);
        primaryStage.setScene(scene);
        primaryStage.show();
    }


    /* Object Code */
    private ArrayList<Order> ord;
    private ArrayList<Table> tables;
    private ArrayList<FoodItem> menu;

    public HandHeldDevice() {
            ord = new ArrayList<Order>();
            tables = new ArrayList<Table>();
            menu = new ArrayList<FoodItem>();

    }


    void markTableAsDirty(int tableNumber){
        tables.get(tableNumber).setStatus(DIRTY);
    }

    void startNewOrder(int ordernum){
        ord.add(new Order(tables.get(ordernum)));
        tables.get(ordernum).setStatus(OCCUPIED);
    }
    public void setMenu(ArrayList<FoodItem> menu) {
        this.menu = menu;
    }


    public FoodItem fetchFoodItem(int id){
        return menu.get(id);
    }

    /* Getters and Setters */
    public ArrayList<Order> getOrd() {
        return ord;
    }

    public void setOrd(ArrayList<Order> ord) {
        this.ord = ord;
    }

    public ArrayList<Table> getTables() {
        return tables;
    }

    public void setTables(ArrayList<Table> tables) {
        this.tables = tables;
    }

    public ArrayList<FoodItem> getMenu() {
        return menu;
    }

        /*
        The following code is only to be used for the demo
        A database and profile functionality is out of the scope
        of this iteration of the project.

        This demo simulates reading in variables from the databases
        and saves them into a main handheld device, which could be one
        of many instances of the same program
        */
        private void demo(){
            // Creates 14 tables
            int[] x = {90,  240, 480, 630, 780, 930,  90, 240, 780, 480, 780, 930, 390, 840, 990, 540, 690, 840, 990};
            int[] y = {100, 100,  95,  95,  95,  95, 200, 200, 190, 190, 250, 250, 300, 300, 300, 420, 420, 420, 420};
            for( int i = 0; i < x.length; i++){
                Table table = new Table(x[i], y[i], i);
                tables.add(table);
            }


            double[] price = {4.99, 3.49, 8.99, 7.99, 23.99};
            String[] Names = {"Chips and Queso", "Guacamole", "Enchiladas", "Taco Plate", "Lasagna"};
            String[] Desc = {"Queso with salsa and spices.", "homemade guacamole, with secret recipe.", "With chicken or beef, 3 enchiladas", "3 tacos of your choosing with beans and rice", "Garfields own lasagna recipe"};

            for( int i = 0; i < 5; i++){
                FoodItem FI = new FoodItem(price[i], Names[i], Desc[i], i);
                menu.add(FI);
            }
            startNewOrder(3);
            startNewOrder(4);
            startNewOrder(2);
            Order orderTwo = ord.get(2);
            orderTwo.addItem(menu.get(3));
            orderTwo.setStatus(COMPLETE);

        }
}
